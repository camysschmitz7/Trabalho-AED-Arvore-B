#ifndef MENU_H
#define MENU_H

// imprime o menu do programa
// pre-condicao: nenhuma
// pos-condicao: nenhuma
// Entrada: nenhum
// Retorno: Nenhum
void imprime_menu();

#endif
